[
          //   {
          //     model: User,
          //     as: "WinnerUser",
          //     attributes: ["username", "id", "name"],
          //   },
          // ],